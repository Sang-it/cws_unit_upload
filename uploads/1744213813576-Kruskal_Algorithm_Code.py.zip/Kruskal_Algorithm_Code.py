class PrimMST:
    def __init__(self, g, start_vertex=0):
        self.weight = 0
        self.mst = Queue()  # This stores the edges of the MST
        self.pq = MinPQ()   # This is the priority queue of edges
        self.marked = [False] * g.V  # Track which vertices are in the MST
        
        # Start from the given start vertex and add all its edges to the priority queue
        self.visit(g, start_vertex)

        while not self.pq.is_empty():
            # Get the edge with the minimum weight
            e = self.pq.del_min()
            v = e.either()  # Get one vertex of the edge
            w = e.other(v)  # Get the other vertex of the edge

            # If both vertices are already in the MST, skip the edge
            if self.marked[v] and self.marked[w]:
                continue

            # Add the edge to the MST
            self.mst.enqueue(e)
            self.weight += e.weight  # Add the edge's weight to the total MST weight

            # Mark the vertex that's not yet in the MST and add all its edges to the priority queue
            if not self.marked[v]:
                self.visit(g, v)
            if not self.marked[w]:
                self.visit(g, w)

    def visit(self, g, v):
        # Mark vertex v as visited and add all its edges to the priority queue
        self.marked[v] = True
        for e in g.adj[v]:
            if not self.marked[e.other(v)]:  # If the other vertex isn't in the MST
                self.pq.insert(e)  # Add the edge to the priority queue

    def edges(self):
        return self.mst.items()  # Return the edges in the MST
